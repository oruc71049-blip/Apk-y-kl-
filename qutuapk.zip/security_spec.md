# Security Specification & Threat Model — QutuAPK

## 1. Data Invariants
1. **Admin-Only App Publishing**: Only verified administrators (`oruc71049@gmail.com` with `email_verified == true` or explicit `/admins/{uid}` document) may create, edit, or delete entries in `/apps/{appId}`.
2. **One Active Review Per User Per App**: Reviews live at `/apps/{appId}/reviews/{userId}` where the document ID MUST match `request.auth.uid`. Firestore's key uniqueness prevents duplicate active reviews by the same user on any app.
3. **Fake Review Prevention (Verified Download Gate)**: A user cannot create a review at `/apps/{appId}/reviews/{userId}` unless `/apps/{appId}/downloads/{request.auth.uid}` already exists and `verifiedDownload == true` and `email_verified == true`.
4. **PII Isolation**: User profiles containing emails (`/users/{userId}`) can only be read by the document owner or an administrator.
5. **Single Report Per User Per Review**: Reports use deterministic IDs `{appId}_{reviewUserId}_{reporterId}` and verify that the target review exists before creation. Terminal report states (`resolved_deleted`, `dismissed`) cannot be altered by non-admins.
6. **Atomic Rating & Download Counters**: Non-admin updates to `/apps/{appId}` are strictly restricted to:
   - Incrementing `downloadCount` by exactly `+1`
   - Updating `ratingSum`, `reviewCount`, `avgRating` strictly alongside an atomic write to `/apps/{appId}/reviews/{request.auth.uid}` verified via `existsAfter()`.
7. **Server-Side Temporal Integrity**: All `createdAt` and `updatedAt` timestamps must equal `request.time`.

## 2. The "Dirty Dozen" Adversarial Payloads
1. **Non-admin APK creation**: Standard user attempts `setDoc(/apps/evil-app, ...)` -> `PERMISSION_DENIED`.
2. **Shadow field injection on App update**: User attempts `updateDoc(/apps/app1, { downloadCount: 10, isFeatured: true })` -> `PERMISSION_DENIED`.
3. **Download counter inflation**: User attempts `updateDoc(/apps/app1, { downloadCount: 999999 })` -> `PERMISSION_DENIED`.
4. **Fake review without downloading APK**: User without `/apps/app1/downloads/{uid}` attempts to create `/apps/app1/reviews/{uid}` -> `PERMISSION_DENIED`.
5. **Duplicate review under different ID**: User attempts to create `/apps/app1/reviews/fake_id_123` -> `PERMISSION_DENIED`.
6. **Identity spoofing in review**: User A attempts to create `/apps/app1/reviews/userB` with `userId: userB` -> `PERMISSION_DENIED`.
7. **Out-of-bounds star rating**: User attempts review with `rating: 10` or `rating: 0` or `rating: 4.5` -> `PERMISSION_DENIED`.
8. **Unverified email spoofing admin**: Unverified token (`email_verified: false`, `email: oruc71049@gmail.com`) attempts admin write -> `PERMISSION_DENIED`.
9. **PII cross-user read**: User A attempts `getDoc(/users/userB)` or `getDocs(/users)` -> `PERMISSION_DENIED`.
10. **Self-promotion to Admin**: User A attempts `setDoc(/admins/userA, ...)` -> `PERMISSION_DENIED`.
11. **Report tampering / status shortcutting**: Reporter attempts to create a report with `status: 'resolved_deleted'` or update a report status -> `PERMISSION_DENIED`.
12. **Resource exhaustion (oversized ID / string)**: Client attempts `setDoc(/apps/app1/reviews/uid, { comment: 'x'.repeat(5000) })` or 500-char doc ID -> `PERMISSION_DENIED`.
