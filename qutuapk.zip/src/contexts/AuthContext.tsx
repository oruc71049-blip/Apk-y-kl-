import {
  onAuthStateChanged,
  signInWithPopup,
  signOut as firebaseSignOut,
  type User,
} from 'firebase/auth';
import { doc, getDoc, serverTimestamp, setDoc, updateDoc } from 'firebase/firestore';
import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react';
import { auth, db, googleProvider, handleFirestoreError, OperationType } from '../lib/firebase';
import { ADMIN_EMAIL, BLUEPRINT_LIMITS, type UserProfile } from '../types/store';

interface AuthContextValue {
  user: User | null;
  profile: UserProfile | null;
  authReady: boolean;
  isAdmin: boolean;
  authError: string | null;
  signingIn: boolean;
  signInWithGoogle: () => Promise<void>;
  signOut: () => Promise<void>;
  updateProfileName: (newName: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [signingIn, setSigningIn] = useState(false);

  const syncUserRecord = useCallback(async (firebaseUser: User) => {
    const userPath = `users/${firebaseUser.uid}`;
    try {
      const userRef = doc(db, 'users', firebaseUser.uid);
      const snap = await getDoc(userRef);
      const fallbackName = (firebaseUser.displayName || firebaseUser.email?.split('@')[0] || 'İstifadəçi')
        .trim()
        .slice(0, BLUEPRINT_LIMITS.displayName.max);

      if (!snap.exists()) {
        const newProfile = {
          uid: firebaseUser.uid,
          displayName: fallbackName,
          email: (firebaseUser.email || '').slice(0, 160),
          photoURL: (firebaseUser.photoURL || '').slice(0, BLUEPRINT_LIMITS.urlMax),
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        };
        await setDoc(userRef, newProfile);
        const createdSnap = await getDoc(userRef);
        if (createdSnap.exists()) {
          setProfile(createdSnap.data() as UserProfile);
        }
      } else {
        setProfile(snap.data() as UserProfile);
      }

      if (firebaseUser.emailVerified && firebaseUser.email === ADMIN_EMAIL) {
        setIsAdmin(true);
      } else {
        try {
          const adminSnap = await getDoc(doc(db, 'admins', firebaseUser.uid));
          setIsAdmin(adminSnap.exists() && firebaseUser.emailVerified);
        } catch {
          setIsAdmin(false);
        }
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, userPath);
    }
  }, []);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (nextUser) => {
      setUser(nextUser);
      if (nextUser) {
        try {
          await syncUserRecord(nextUser);
        } catch (err) {
          console.error('Failed syncing user record:', err);
        }
      } else {
        setProfile(null);
        setIsAdmin(false);
      }
      setAuthReady(true);
    });
    return () => unsubscribe();
  }, [syncUserRecord]);

  const signInWithGoogle = useCallback(async () => {
    setAuthError(null);
    setSigningIn(true);
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Giriş zamanı xəta baş verdi.';
      if (!message.includes('popup-closed-by-user')) {
        setAuthError('Google hesabı ilə giriş alınmadı. Yenidən cəhd edin.');
      }
    } finally {
      setSigningIn(false);
    }
  }, []);

  const signOut = useCallback(async () => {
    await firebaseSignOut(auth);
  }, []);

  const updateProfileName = useCallback(
    async (newName: string) => {
      if (!user) return;
      const trimmed = newName.trim().slice(0, BLUEPRINT_LIMITS.displayName.max);
      if (trimmed.length < BLUEPRINT_LIMITS.displayName.min) {
        throw new Error('Ad ən azı 1 simvoldan ibarət olmalıdır.');
      }
      const userPath = `users/${user.uid}`;
      try {
        await updateDoc(doc(db, 'users', user.uid), {
          displayName: trimmed,
          updatedAt: serverTimestamp(),
        });
        setProfile((prev) => (prev ? { ...prev, displayName: trimmed } : prev));
      } catch (error) {
        handleFirestoreError(error, OperationType.UPDATE, userPath);
      }
    },
    [user],
  );

  return (
    <AuthContext.Provider
      value={{
        user,
        profile,
        authReady,
        isAdmin,
        authError,
        signingIn,
        signInWithGoogle,
        signOut,
        updateProfileName,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error('useAuth must be used inside AuthProvider');
  }
  return ctx;
}
