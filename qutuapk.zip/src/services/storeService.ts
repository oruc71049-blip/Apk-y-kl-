import type { User } from 'firebase/auth';
import {
  collection,
  doc,
  getDoc,
  getDocs,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import {
  APP_CATEGORIES,
  BLUEPRINT_LIMITS,
  type AppFormInput,
  type AppListing,
  type AppReview,
  type DownloadReceipt,
  type ReportReason,
  type ReviewReport,
} from '../types/store';

export function validateAppFormInput(input: AppFormInput): string | null {
  const name = input.name.trim();
  const pkg = input.packageName.trim();
  const shortDesc = input.shortDescription.trim();
  const desc = input.description.trim();
  const version = input.version.trim();

  if (name.length < BLUEPRINT_LIMITS.appName.min || name.length > BLUEPRINT_LIMITS.appName.max) {
    return `Tətbiqin adı ${BLUEPRINT_LIMITS.appName.min}–${BLUEPRINT_LIMITS.appName.max} simvol arası olmalıdır.`;
  }
  if (
    pkg.length < BLUEPRINT_LIMITS.packageName.min ||
    pkg.length > BLUEPRINT_LIMITS.packageName.max ||
    !BLUEPRINT_LIMITS.packageNamePattern.test(pkg)
  ) {
    return 'Paket adı düzgün formatda deyil (məs: az.qutuapk.app).';
  }
  if (
    shortDesc.length < BLUEPRINT_LIMITS.shortDescription.min ||
    shortDesc.length > BLUEPRINT_LIMITS.shortDescription.max
  ) {
    return `Qısa təsvir ${BLUEPRINT_LIMITS.shortDescription.min}–${BLUEPRINT_LIMITS.shortDescription.max} simvol arası olmalıdır.`;
  }
  if (
    desc.length < BLUEPRINT_LIMITS.description.min ||
    desc.length > BLUEPRINT_LIMITS.description.max
  ) {
    return `Ətraflı təsvir ${BLUEPRINT_LIMITS.description.min}–${BLUEPRINT_LIMITS.description.max} simvol arası olmalıdır.`;
  }
  if (!APP_CATEGORIES.includes(input.category)) {
    return 'Düzgün kateqoriya seçin.';
  }
  if (
    version.length < BLUEPRINT_LIMITS.version.min ||
    version.length > BLUEPRINT_LIMITS.version.max ||
    !BLUEPRINT_LIMITS.versionPattern.test(version)
  ) {
    return 'Versiya düzgün formatda deyil (məs: 1.4.2).';
  }
  if (!input.apkFileName || !input.apkDownloadUrl || input.fileSizeBytes <= 0) {
    return 'Zəhmət olmasa .apk faylı yükləyin.';
  }
  if (!input.iconUrl || input.iconUrl.length > BLUEPRINT_LIMITS.urlMax) {
    return 'Tətbiq loqosu seçin və ya yükləyin.';
  }
  if (input.screenshotUrls.length > BLUEPRINT_LIMITS.maxScreenshots) {
    return `Maksimum ${BLUEPRINT_LIMITS.maxScreenshots} ekran görüntüsü əlavə edilə bilər.`;
  }
  return null;
}

export function subscribeApps(
  onData: (apps: AppListing[]) => void,
  onError?: (err: Error) => void,
): () => void {
  const path = 'apps';
  const q = query(collection(db, path), orderBy('updatedAt', 'desc'));
  return onSnapshot(
    q,
    (snapshot) => {
      const list = snapshot.docs.map((d) => ({ ...d.data(), id: d.id }) as AppListing);
      onData(list);
    },
    (error) => {
      try {
        handleFirestoreError(error, OperationType.LIST, path);
      } catch (wrapped) {
        if (onError && wrapped instanceof Error) onError(wrapped);
      }
    },
  );
}

export function subscribeApp(
  appId: string,
  onData: (app: AppListing | null) => void,
  onError?: (err: Error) => void,
): () => void {
  const path = `apps/${appId}`;
  return onSnapshot(
    doc(db, 'apps', appId),
    (snap) => {
      if (!snap.exists()) {
        onData(null);
        return;
      }
      onData({ ...snap.data(), id: snap.id } as AppListing);
    },
    (error) => {
      try {
        handleFirestoreError(error, OperationType.GET, path);
      } catch (wrapped) {
        if (onError && wrapped instanceof Error) onError(wrapped);
      }
    },
  );
}

export function subscribeReviews(
  appId: string,
  onData: (reviews: AppReview[]) => void,
  onError?: (err: Error) => void,
): () => void {
  const path = `apps/${appId}/reviews`;
  const q = query(collection(db, 'apps', appId, 'reviews'), orderBy('updatedAt', 'desc'));
  return onSnapshot(
    q,
    (snapshot) => {
      const reviews = snapshot.docs.map((d) => d.data() as AppReview);
      onData(reviews);
    },
    (error) => {
      try {
        handleFirestoreError(error, OperationType.LIST, path);
      } catch (wrapped) {
        if (onError && wrapped instanceof Error) onError(wrapped);
      }
    },
  );
}

export function subscribeUserDownloadReceipt(
  appId: string,
  userId: string | undefined,
  onData: (receipt: DownloadReceipt | null) => void,
): () => void {
  if (!userId) {
    onData(null);
    return () => {};
  }
  const path = `apps/${appId}/downloads/${userId}`;
  return onSnapshot(
    doc(db, 'apps', appId, 'downloads', userId),
    (snap) => {
      onData(snap.exists() ? (snap.data() as DownloadReceipt) : null);
    },
    (error) => {
      handleFirestoreError(error, OperationType.GET, path);
    },
  );
}

export function subscribeReports(
  isAdmin: boolean,
  userId: string | undefined,
  onData: (reports: ReviewReport[]) => void,
): () => void {
  if (!userId) {
    onData([]);
    return () => {};
  }
  const path = 'reports';
  const q = isAdmin
    ? query(collection(db, path), orderBy('createdAt', 'desc'))
    : query(collection(db, path), where('reporterId', '==', userId));

  return onSnapshot(
    q,
    (snapshot) => {
      const items = snapshot.docs.map((d) => ({ ...d.data(), id: d.id }) as ReviewReport);
      items.sort((a, b) => {
        const aTime = a.createdAt?.toMillis?.() ?? 0;
        const bTime = b.createdAt?.toMillis?.() ?? 0;
        return bTime - aTime;
      });
      onData(items);
    },
    (error) => {
      handleFirestoreError(error, OperationType.LIST, path);
    },
  );
}

export async function uploadApkFile(
  file: File,
  idToken: string,
): Promise<{
  apkFileName: string;
  apkDownloadUrl: string;
  fileSizeBytes: number;
  fileSizeLabel: string;
}> {
  const formData = new FormData();
  formData.append('apk', file);
  const res = await fetch('/api/upload/apk', {
    method: 'POST',
    headers: { Authorization: `Bearer ${idToken}` },
    body: formData,
  });
  const data = (await res.json()) as {
    error?: string;
    apkFileName?: string;
    apkDownloadUrl?: string;
    fileSizeBytes?: number;
    fileSizeLabel?: string;
  };
  if (!res.ok || !data.apkFileName || !data.apkDownloadUrl) {
    throw new Error(data.error || 'APK faylı yüklənə bilmədi.');
  }
  return {
    apkFileName: data.apkFileName,
    apkDownloadUrl: data.apkDownloadUrl,
    fileSizeBytes: data.fileSizeBytes ?? file.size,
    fileSizeLabel: data.fileSizeLabel ?? `${(file.size / (1024 * 1024)).toFixed(1)} MB`,
  };
}

export async function uploadMediaFile(file: File, idToken: string): Promise<string> {
  const formData = new FormData();
  formData.append('image', file);
  const res = await fetch('/api/upload/media', {
    method: 'POST',
    headers: { Authorization: `Bearer ${idToken}` },
    body: formData,
  });
  const data = (await res.json()) as { error?: string; url?: string };
  if (!res.ok || !data.url) {
    throw new Error(data.error || 'Şəkil yüklənə bilmədi.');
  }
  return data.url;
}

function buildSafeAppId(name: string): string {
  const slug = name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '')
    .slice(0, 40);
  const suffix = Math.random().toString(36).slice(2, 8);
  return `${slug || 'app'}_${suffix}`;
}

export async function createAppListing(input: AppFormInput, adminUser: User): Promise<string> {
  const validationError = validateAppFormInput(input);
  if (validationError) {
    throw new Error(validationError);
  }
  const appId = buildSafeAppId(input.name);
  const path = `apps/${appId}`;
  const payload = {
    id: appId,
    name: input.name.trim().slice(0, BLUEPRINT_LIMITS.appName.max),
    packageName: input.packageName.trim().slice(0, BLUEPRINT_LIMITS.packageName.max),
    shortDescription: input.shortDescription.trim().slice(0, BLUEPRINT_LIMITS.shortDescription.max),
    description: input.description.trim().slice(0, BLUEPRINT_LIMITS.description.max),
    category: input.category,
    version: input.version.trim().slice(0, BLUEPRINT_LIMITS.version.max),
    fileSizeBytes: Math.round(input.fileSizeBytes),
    fileSizeLabel: input.fileSizeLabel.trim().slice(0, 24),
    iconUrl: input.iconUrl.trim().slice(0, BLUEPRINT_LIMITS.urlMax),
    screenshotUrls: input.screenshotUrls
      .map((s) => s.trim().slice(0, BLUEPRINT_LIMITS.urlMax))
      .filter(Boolean)
      .slice(0, BLUEPRINT_LIMITS.maxScreenshots),
    apkFileName: input.apkFileName.trim().slice(0, 200),
    apkDownloadUrl: input.apkDownloadUrl.trim().slice(0, BLUEPRINT_LIMITS.urlMax),
    downloadCount: 0,
    ratingSum: 0,
    reviewCount: 0,
    avgRating: 0,
    createdBy: adminUser.uid,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };

  try {
    await setDoc(doc(db, 'apps', appId), payload);
    return appId;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function updateAppListing(appId: string, input: AppFormInput): Promise<void> {
  const validationError = validateAppFormInput(input);
  if (validationError) {
    throw new Error(validationError);
  }
  const path = `apps/${appId}`;
  try {
    await updateDoc(doc(db, 'apps', appId), {
      name: input.name.trim().slice(0, BLUEPRINT_LIMITS.appName.max),
      packageName: input.packageName.trim().slice(0, BLUEPRINT_LIMITS.packageName.max),
      shortDescription: input.shortDescription.trim().slice(0, BLUEPRINT_LIMITS.shortDescription.max),
      description: input.description.trim().slice(0, BLUEPRINT_LIMITS.description.max),
      category: input.category,
      version: input.version.trim().slice(0, BLUEPRINT_LIMITS.version.max),
      fileSizeBytes: Math.round(input.fileSizeBytes),
      fileSizeLabel: input.fileSizeLabel.trim().slice(0, 24),
      iconUrl: input.iconUrl.trim().slice(0, BLUEPRINT_LIMITS.urlMax),
      screenshotUrls: input.screenshotUrls
        .map((s) => s.trim().slice(0, BLUEPRINT_LIMITS.urlMax))
        .filter(Boolean)
        .slice(0, BLUEPRINT_LIMITS.maxScreenshots),
      apkFileName: input.apkFileName.trim().slice(0, 200),
      apkDownloadUrl: input.apkDownloadUrl.trim().slice(0, BLUEPRINT_LIMITS.urlMax),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function deleteAppListing(app: AppListing, idToken: string): Promise<void> {
  const path = `apps/${app.id}`;
  try {
    const reviewsSnap = await getDocs(collection(db, 'apps', app.id, 'reviews'));
    const downloadsSnap = await getDocs(collection(db, 'apps', app.id, 'downloads'));

    const batch = writeBatch(db);
    reviewsSnap.forEach((d) => batch.delete(d.ref));
    downloadsSnap.forEach((d) => batch.delete(d.ref));
    batch.delete(doc(db, 'apps', app.id));
    await batch.commit();

    if (app.apkFileName) {
      await fetch(`/api/apks/${encodeURIComponent(app.apkFileName)}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${idToken}` },
      });
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export async function recordDownloadAndTrigger(app: AppListing, user: User | null): Promise<void> {
  if (user && user.emailVerified) {
    const receiptPath = `apps/${app.id}/downloads/${user.uid}`;
    const receiptRef = doc(db, 'apps', app.id, 'downloads', user.uid);
    const appRef = doc(db, 'apps', app.id);

    try {
      const existingReceipt = await getDoc(receiptRef);
      if (!existingReceipt.exists()) {
        const batch = writeBatch(db);
        batch.set(receiptRef, {
          appId: app.id,
          userId: user.uid,
          version: app.version,
          downloadedAt: serverTimestamp(),
          lastDownloadedAt: serverTimestamp(),
        });
        batch.update(appRef, {
          downloadCount: app.downloadCount + 1,
        });
        await batch.commit();
      } else {
        await updateDoc(receiptRef, {
          version: app.version,
          lastDownloadedAt: serverTimestamp(),
        });
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, receiptPath);
    }
  }

  const downloadUrl = `${app.apkDownloadUrl}?name=${encodeURIComponent(`${app.name}-v${app.version}.apk`)}`;
  const anchor = document.createElement('a');
  anchor.href = downloadUrl;
  anchor.download = `${app.name}-v${app.version}.apk`;
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
}

export async function submitOrUpdateReview(
  app: AppListing,
  user: User,
  displayName: string,
  rating: number,
  comment: string,
  existingReview: AppReview | null,
): Promise<void> {
  const cleanRating = Math.round(rating);
  if (cleanRating < 1 || cleanRating > 5) {
    throw new Error('Qiymət 1 ilə 5 ulduz arasında olmalıdır.');
  }
  const trimmedComment = comment.trim().slice(0, BLUEPRINT_LIMITS.comment.max);
  if (trimmedComment.length < BLUEPRINT_LIMITS.comment.min) {
    throw new Error(`Rəy ən azı ${BLUEPRINT_LIMITS.comment.min} simvoldan ibarət olmalıdır.`);
  }
  const cleanName = (displayName || user.displayName || 'İstifadəçi')
    .trim()
    .slice(0, BLUEPRINT_LIMITS.displayName.max);

  const reviewPath = `apps/${app.id}/reviews/${user.uid}`;
  const reviewRef = doc(db, 'apps', app.id, 'reviews', user.uid);
  const appRef = doc(db, 'apps', app.id);

  try {
    const batch = writeBatch(db);
    if (!existingReview) {
      const nextSum = app.ratingSum + cleanRating;
      const nextCount = app.reviewCount + 1;
      const nextAvg = Number((nextSum / nextCount).toFixed(2));

      batch.set(reviewRef, {
        appId: app.id,
        userId: user.uid,
        userName: cleanName,
        rating: cleanRating,
        comment: trimmedComment,
        verifiedDownload: true,
        status: 'active',
        reportCount: 0,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      batch.update(appRef, {
        ratingSum: nextSum,
        reviewCount: nextCount,
        avgRating: nextAvg,
      });
    } else {
      const delta = cleanRating - existingReview.rating;
      const nextSum = Math.max(0, app.ratingSum + delta);
      const nextAvg = app.reviewCount > 0 ? Number((nextSum / app.reviewCount).toFixed(2)) : 0;

      batch.update(reviewRef, {
        rating: cleanRating,
        comment: trimmedComment,
        userName: cleanName,
        updatedAt: serverTimestamp(),
      });
      batch.update(appRef, {
        ratingSum: nextSum,
        reviewCount: app.reviewCount,
        avgRating: nextAvg,
      });
    }
    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, reviewPath);
  }
}

export async function deleteOwnReview(app: AppListing, review: AppReview): Promise<void> {
  const reviewPath = `apps/${app.id}/reviews/${review.userId}`;
  const reviewRef = doc(db, 'apps', app.id, 'reviews', review.userId);
  const appRef = doc(db, 'apps', app.id);

  const nextCount = Math.max(0, app.reviewCount - 1);
  const nextSum = Math.max(0, app.ratingSum - review.rating);
  const nextAvg = nextCount > 0 ? Number((nextSum / nextCount).toFixed(2)) : 0;

  try {
    const batch = writeBatch(db);
    batch.delete(reviewRef);
    batch.update(appRef, {
      ratingSum: nextSum,
      reviewCount: nextCount,
      avgRating: nextAvg,
    });
    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, reviewPath);
  }
}

export async function submitReport(
  app: AppListing,
  review: AppReview,
  reporter: User,
  reporterName: string,
  reason: ReportReason,
  details: string,
): Promise<void> {
  const reportId = `${app.id}__${review.userId}__${reporter.uid}`;
  const path = `reports/${reportId}`;
  try {
    await setDoc(doc(db, 'reports', reportId), {
      appId: app.id,
      appName: app.name.slice(0, BLUEPRINT_LIMITS.appName.max),
      reviewUserId: review.userId,
      reviewUserName: review.userName.slice(0, BLUEPRINT_LIMITS.displayName.max),
      reviewComment: review.comment.slice(0, BLUEPRINT_LIMITS.comment.max),
      reporterId: reporter.uid,
      reporterName: (reporterName || reporter.displayName || 'İstifadəçi').slice(
        0,
        BLUEPRINT_LIMITS.displayName.max,
      ),
      reason,
      details: details.trim().slice(0, BLUEPRINT_LIMITS.detailsMax),
      status: 'pending',
      adminNote: '',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function adminDeleteReview(
  app: AppListing,
  reviewUserId: string,
  reportId?: string,
  adminNote = 'Rəy qaydaları pozduğu üçün silindi.',
): Promise<void> {
  const reviewPath = `apps/${app.id}/reviews/${reviewUserId}`;
  try {
    const reviewsSnap = await getDocs(collection(db, 'apps', app.id, 'reviews'));
    let nextSum = 0;
    let nextCount = 0;

    reviewsSnap.forEach((docSnap) => {
      if (docSnap.id !== reviewUserId) {
        const data = docSnap.data() as AppReview;
        nextSum += data.rating;
        nextCount += 1;
      }
    });

    const nextAvg = nextCount > 0 ? Number((nextSum / nextCount).toFixed(2)) : 0;

    const batch = writeBatch(db);
    batch.delete(doc(db, 'apps', app.id, 'reviews', reviewUserId));
    batch.update(doc(db, 'apps', app.id), {
      ratingSum: nextSum,
      reviewCount: nextCount,
      avgRating: nextAvg,
      updatedAt: serverTimestamp(),
    });

    if (reportId) {
      batch.update(doc(db, 'reports', reportId), {
        status: 'resolved_deleted',
        adminNote: adminNote.slice(0, BLUEPRINT_LIMITS.detailsMax),
        updatedAt: serverTimestamp(),
      });
    }
    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, reviewPath);
  }
}

export async function adminDismissReport(reportId: string, adminNote: string): Promise<void> {
  const path = `reports/${reportId}`;
  try {
    await updateDoc(doc(db, 'reports', reportId), {
      status: 'dismissed',
      adminNote: (adminNote.trim() || 'Yoxlanıldı, pozuntu aşkar edilmədi.').slice(
        0,
        BLUEPRINT_LIMITS.detailsMax,
      ),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function fetchAllReviewsForAdmin(apps: AppListing[]): Promise<AppReview[]> {
  const results: AppReview[] = [];
  for (const app of apps) {
    const path = `apps/${app.id}/reviews`;
    try {
      const snap = await getDocs(collection(db, 'apps', app.id, 'reviews'));
      snap.forEach((d) => results.push(d.data() as AppReview));
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, path);
    }
  }
  results.sort((a, b) => (b.updatedAt?.toMillis?.() ?? 0) - (a.updatedAt?.toMillis?.() ?? 0));
  return results;
}
