import {
  AlertTriangle,
  Check,
  Edit3,
  ExternalLink,
  FileArchive,
  Flag,
  ImagePlus,
  Plus,
  ShieldCheck,
  Trash2,
  Upload,
  X,
} from 'lucide-react';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import {
  adminDeleteReview,
  adminDismissReport,
  createAppListing,
  deleteAppListing,
  fetchAllReviewsForAdmin,
  updateAppListing,
  uploadApkFile,
  uploadMediaFile,
  validateAppFormInput,
} from '../services/storeService';
import {
  APP_CATEGORIES,
  BLUEPRINT_LIMITS,
  STUDIO_ASSETS,
  type AppCategory,
  type AppFormInput,
  type AppListing,
  type AppReview,
  type ReviewReport,
} from '../types/store';
import { SafeImage } from './SafeImage';
import { StarRatingDisplay } from './StarRating';

interface AdminPanelViewProps {
  apps: AppListing[];
  reports: ReviewReport[];
  initialOpenCreate?: boolean;
  onConsumeInitialCreate?: () => void;
  onOpenApp: (appId: string) => void;
  onBackToStore: () => void;
}

const EMPTY_FORM: AppFormInput = {
  name: '',
  packageName: '',
  shortDescription: '',
  description: '',
  category: 'Məhsuldarlıq',
  version: '1.0.0',
  fileSizeBytes: 0,
  fileSizeLabel: '',
  iconUrl: STUDIO_ASSETS.icons[0].url,
  screenshotUrls: [STUDIO_ASSETS.screenshotShowcase],
  apkFileName: '',
  apkDownloadUrl: '',
};

type AdminTab = 'apps' | 'moderation';

export function AdminPanelView({
  apps,
  reports,
  initialOpenCreate = false,
  onConsumeInitialCreate,
  onOpenApp,
  onBackToStore,
}: AdminPanelViewProps) {
  const { user, isAdmin } = useAuth();
  const [activeTab, setActiveTab] = useState<AdminTab>('apps');

  // Create / Edit Form state
  const [formOpen, setFormOpen] = useState(initialOpenCreate);
  const [editingAppId, setEditingAppId] = useState<string | null>(null);
  const [form, setForm] = useState<AppFormInput>(EMPTY_FORM);
  const [uploadingApk, setUploadingApk] = useState(false);
  const [uploadingMedia, setUploadingMedia] = useState(false);
  const [savingApp, setSavingApp] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [statusNotice, setStatusNotice] = useState<string | null>(null);
  const [confirmDeleteAppId, setConfirmDeleteAppId] = useState<string | null>(null);

  // Moderation state
  const [allReviews, setAllReviews] = useState<AppReview[]>([]);
  const [loadingReviews, setLoadingReviews] = useState(false);
  const [adminNoteByReport, setAdminNoteByReport] = useState<Record<string, string>>({});

  useEffect(() => {
    if (initialOpenCreate) {
      setEditingAppId(null);
      setForm(EMPTY_FORM);
      setFormError(null);
      setFormOpen(true);
      onConsumeInitialCreate?.();
    }
  }, [initialOpenCreate, onConsumeInitialCreate]);

  const loadAllReviews = useCallback(async () => {
    if (!isAdmin || apps.length === 0) {
      setAllReviews([]);
      return;
    }
    setLoadingReviews(true);
    try {
      const list = await fetchAllReviewsForAdmin(apps);
      setAllReviews(list);
    } finally {
      setLoadingReviews(false);
    }
  }, [apps, isAdmin]);

  useEffect(() => {
    if (activeTab === 'moderation') {
      void loadAllReviews();
    }
  }, [activeTab, loadAllReviews]);

  const metrics = useMemo(() => {
    const totalDownloads = apps.reduce((sum, a) => sum + (a.downloadCount || 0), 0);
    const totalReviews = apps.reduce((sum, a) => sum + (a.reviewCount || 0), 0);
    const pendingReports = reports.filter((r) => r.status === 'pending').length;
    return {
      totalApps: apps.length,
      totalDownloads,
      totalReviews,
      pendingReports,
    };
  }, [apps, reports]);

  const appMap = useMemo(() => {
    const map = new Map<string, AppListing>();
    apps.forEach((a) => map.set(a.id, a));
    return map;
  }, [apps]);

  if (!isAdmin || !user) {
    return (
      <div className="max-w-xl mx-auto px-4 py-16 text-center">
        <div className="bg-white border border-slate-200 rounded-2xl p-8 space-y-4">
          <div className="w-12 h-12 rounded-xl bg-red-50 text-red-600 flex items-center justify-center mx-auto">
            <AlertTriangle className="w-6 h-6" />
          </div>
          <h1 className="font-display text-xl font-bold text-slate-900">
            Admin girişi tələb olunur
          </h1>
          <p className="text-sm text-slate-600">
            Bu bölmə yalnız mağaza administratoru tərəfindən idarə olunur.
          </p>
          <button
            type="button"
            onClick={onBackToStore}
            className="px-4 py-2 text-sm font-medium text-white bg-slate-900 rounded-lg"
          >
            Mağazaya qayıt
          </button>
        </div>
      </div>
    );
  }

  const handleOpenCreate = () => {
    setEditingAppId(null);
    setForm(EMPTY_FORM);
    setFormError(null);
    setFormOpen(true);
  };

  const handleOpenEdit = (app: AppListing) => {
    setEditingAppId(app.id);
    setForm({
      name: app.name,
      packageName: app.packageName,
      shortDescription: app.shortDescription,
      description: app.description,
      category: app.category,
      version: app.version,
      fileSizeBytes: app.fileSizeBytes,
      fileSizeLabel: app.fileSizeLabel,
      iconUrl: app.iconUrl,
      screenshotUrls: app.screenshotUrls || [],
      apkFileName: app.apkFileName,
      apkDownloadUrl: app.apkDownloadUrl,
    });
    setFormError(null);
    setFormOpen(true);
  };

  const handleApkFileChange = async (file: File | undefined) => {
    if (!file) return;
    if (!file.name.toLowerCase().endsWith('.apk')) {
      setFormError('Yalnız .apk genişlənməli fayllar yüklənə bilər.');
      return;
    }
    setFormError(null);
    setUploadingApk(true);
    try {
      const idToken = await user.getIdToken();
      const uploaded = await uploadApkFile(file, idToken);
      const cleanName = file.name.replace(/\.apk$/i, '').replace(/[_-]+/g, ' ').trim();
      setForm((prev) => ({
        ...prev,
        apkFileName: uploaded.apkFileName,
        apkDownloadUrl: uploaded.apkDownloadUrl,
        fileSizeBytes: uploaded.fileSizeBytes,
        fileSizeLabel: uploaded.fileSizeLabel,
        name: prev.name || cleanName.slice(0, BLUEPRINT_LIMITS.appName.max),
        packageName:
          prev.packageName ||
          `az.qutuapk.${cleanName.toLowerCase().replace(/[^a-z0-9]/g, '') || 'app'}`,
      }));
    } catch (err) {
      setFormError(err instanceof Error ? err.message : 'APK yüklənərkən xəta baş verdi.');
    } finally {
      setUploadingApk(false);
    }
  };

  const handleIconFileChange = async (file: File | undefined) => {
    if (!file) return;
    setFormError(null);
    setUploadingMedia(true);
    try {
      const idToken = await user.getIdToken();
      const url = await uploadMediaFile(file, idToken);
      setForm((prev) => ({ ...prev, iconUrl: url }));
    } catch (err) {
      setFormError(err instanceof Error ? err.message : 'Loqo yüklənmədi.');
    } finally {
      setUploadingMedia(false);
    }
  };

  const handleScreenshotsAdd = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    const remaining = BLUEPRINT_LIMITS.maxScreenshots - form.screenshotUrls.length;
    if (remaining <= 0) {
      setFormError(`Maksimum ${BLUEPRINT_LIMITS.maxScreenshots} ekran görüntüsü əlavə edilə bilər.`);
      return;
    }
    setFormError(null);
    setUploadingMedia(true);
    try {
      const idToken = await user.getIdToken();
      const selected = Array.from(files).slice(0, remaining);
      const uploadedUrls: string[] = [];
      for (const f of selected) {
        const url = await uploadMediaFile(f, idToken);
        uploadedUrls.push(url);
      }
      setForm((prev) => ({
        ...prev,
        screenshotUrls: [...prev.screenshotUrls, ...uploadedUrls].slice(
          0,
          BLUEPRINT_LIMITS.maxScreenshots,
        ),
      }));
    } catch (err) {
      setFormError(err instanceof Error ? err.message : 'Ekran görüntüsü yüklənmədi.');
    } finally {
      setUploadingMedia(false);
    }
  };

  const handleSaveApp = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    const validationErr = validateAppFormInput(form);
    if (validationErr) {
      setFormError(validationErr);
      return;
    }
    setSavingApp(true);
    try {
      if (editingAppId) {
        await updateAppListing(editingAppId, form);
        setStatusNotice(`"${form.name}" tətbiqi yeniləndi.`);
      } else {
        await createAppListing(form, user);
        setStatusNotice(`"${form.name}" mağazada dərc olundu.`);
      }
      setFormOpen(false);
      setEditingAppId(null);
      setForm(EMPTY_FORM);
    } catch (err) {
      setFormError(err instanceof Error ? err.message : 'Tətbiq yadda saxlanılmadı.');
    } finally {
      setSavingApp(false);
    }
  };

  const handleDeleteApp = async (app: AppListing) => {
    try {
      const idToken = await user.getIdToken();
      await deleteAppListing(app, idToken);
      setConfirmDeleteAppId(null);
      setStatusNotice(`"${app.name}" mağazadan silindi.`);
    } catch (err) {
      setStatusNotice(err instanceof Error ? err.message : 'Silinmə zamanı xəta baş verdi.');
    }
  };

  const handleResolveReportDelete = async (report: ReviewReport) => {
    const app = appMap.get(report.appId);
    if (!app) return;
    const note = adminNoteByReport[report.id] || 'Saxta və ya qayda pozan rəy silindi.';
    try {
      await adminDeleteReview(app, report.reviewUserId, report.id, note);
      setStatusNotice('Rəy silindi və şikayət həll edildi.');
      await loadAllReviews();
    } catch (err) {
      setStatusNotice(err instanceof Error ? err.message : 'Əməliyyat alınmadı.');
    }
  };

  const handleDismissReport = async (report: ReviewReport) => {
    const note = adminNoteByReport[report.id] || 'Yoxlanıldı, qayda pozuntusu aşkar edilmədi.';
    try {
      await adminDismissReport(report.id, note);
      setStatusNotice('Şikayət rədd edildi.');
    } catch (err) {
      setStatusNotice(err instanceof Error ? err.message : 'Əməliyyat alınmadı.');
    }
  };

  const handleDirectAdminDeleteReview = async (review: AppReview) => {
    const app = appMap.get(review.appId);
    if (!app) return;
    try {
      await adminDeleteReview(app, review.userId);
      setStatusNotice('Rəy moderator tərəfindən silindi.');
      await loadAllReviews();
    } catch (err) {
      setStatusNotice(err instanceof Error ? err.message : 'Rəy silinmədi.');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 pb-20 space-y-8">
      {/* Workspace Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-6 border-b border-slate-200">
        <div>
          <p className="text-xs font-medium text-blue-700 inline-flex items-center gap-1.5 mb-1">
            <ShieldCheck className="w-4 h-4" />
            Yalnız Administrator Girişi · {user.email}
          </p>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-slate-900">
            Mağaza İdarəetmə Paneli
          </h1>
        </div>
        <button
          type="button"
          onClick={handleOpenCreate}
          className="inline-flex items-center justify-center gap-2 px-5 py-2.5 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-xl transition-colors whitespace-nowrap shrink-0"
        >
          <Plus className="w-4 h-4" />
          Yeni APK Əlavə Et
        </button>
      </div>

      {/* 4-column KPI Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <p className="text-xs text-slate-500">Aktiv tətbiqlər</p>
          <p className="font-display text-2xl font-bold text-slate-900 mt-1 tabular-nums">
            {metrics.totalApps}
          </p>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <p className="text-xs text-slate-500">Ümumi APK yükləmə</p>
          <p className="font-display text-2xl font-bold text-slate-900 mt-1 tabular-nums">
            {metrics.totalDownloads.toLocaleString('az-AZ')}
          </p>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <p className="text-xs text-slate-500">Təsdiqlənmiş rəylər</p>
          <p className="font-display text-2xl font-bold text-slate-900 mt-1 tabular-nums">
            {metrics.totalReviews}
          </p>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <p className="text-xs text-slate-500">Gözləyən şikayətlər</p>
          <p
            className={`font-display text-2xl font-bold mt-1 tabular-nums ${
              metrics.pendingReports > 0 ? 'text-amber-600' : 'text-slate-900'
            }`}
          >
            {metrics.pendingReports}
          </p>
        </div>
      </div>

      {statusNotice ? (
        <div className="px-4 py-3 bg-emerald-50 border border-emerald-200 rounded-xl text-sm text-emerald-800 flex items-center justify-between gap-4">
          <span>{statusNotice}</span>
          <button
            type="button"
            onClick={() => setStatusNotice(null)}
            className="text-xs font-medium underline whitespace-nowrap"
          >
            Bağla
          </button>
        </div>
      ) : null}

      {/* Admin Sub-Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200">
        <button
          type="button"
          onClick={() => setActiveTab('apps')}
          className={`px-4 py-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
            activeTab === 'apps'
              ? 'border-blue-700 text-blue-700'
              : 'border-transparent text-slate-600 hover:text-slate-900'
          }`}
        >
          Tətbiqlər və APK faylları ({apps.length})
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('moderation')}
          className={`px-4 py-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap inline-flex items-center gap-2 ${
            activeTab === 'moderation'
              ? 'border-blue-700 text-blue-700'
              : 'border-transparent text-slate-600 hover:text-slate-900'
          }`}
        >
          <Flag className="w-4 h-4" />
          Şikayətlər və Rəy Moderasiyası ({metrics.pendingReports} gözləyən)
        </button>
      </div>

      {/* Tab 1: Apps Table */}
      {activeTab === 'apps' ? (
        <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
          {apps.length === 0 ? (
            <div className="p-12 text-center space-y-4">
              <p className="text-base font-medium text-slate-900">Hələ APK əlavə edilməyib</p>
              <p className="text-sm text-slate-500 max-w-md mx-auto">
                İlk Android APK faylınızı yükləyin, loqo, ekran görüntüləri və versiya məlumatını
                əlavə edərək mağazada dərc edin.
              </p>
              <button
                type="button"
                onClick={handleOpenCreate}
                className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-lg"
              >
                <Plus className="w-4 h-4" />
                Yeni APK Əlavə Et
              </button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-xs font-medium text-slate-500">
                    <th className="py-3.5 px-5">Tətbiq</th>
                    <th className="py-3.5 px-4">Kateqoriya</th>
                    <th className="py-3.5 px-4">Versiya</th>
                    <th className="py-3.5 px-4 text-right">Ölçü</th>
                    <th className="py-3.5 px-4 text-right">Yükləmə</th>
                    <th className="py-3.5 px-4">Reytinq</th>
                    <th className="py-3.5 px-5 text-right">Əməliyyatlar</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  {apps.map((app) => (
                    <tr key={app.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3.5 px-5">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-xl overflow-hidden border border-slate-200 bg-slate-100 shrink-0">
                            <SafeImage
                              src={app.iconUrl}
                              alt={app.name}
                              className="w-full h-full object-cover"
                            />
                          </div>
                          <div className="min-w-0">
                            <p className="font-semibold text-slate-900 truncate max-w-[200px]">
                              {app.name}
                            </p>
                            <p className="text-xs font-mono text-slate-500 truncate max-w-[200px]">
                              {app.packageName}
                            </p>
                          </div>
                        </div>
                      </td>
                      <td className="py-3.5 px-4 text-slate-700 whitespace-nowrap">
                        {app.category}
                      </td>
                      <td className="py-3.5 px-4 font-mono text-xs text-slate-700 whitespace-nowrap">
                        v{app.version}
                      </td>
                      <td className="py-3.5 px-4 text-right text-slate-700 tabular-nums whitespace-nowrap">
                        {app.fileSizeLabel}
                      </td>
                      <td className="py-3.5 px-4 text-right font-medium text-slate-900 tabular-nums whitespace-nowrap">
                        {app.downloadCount.toLocaleString('az-AZ')}
                      </td>
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <StarRatingDisplay
                          rating={app.avgRating}
                          reviewCount={app.reviewCount}
                        />
                      </td>
                      <td className="py-3.5 px-5 text-right whitespace-nowrap">
                        {confirmDeleteAppId === app.id ? (
                          <div className="inline-flex items-center gap-2">
                            <span className="text-xs text-red-600 font-medium">Silinsin?</span>
                            <button
                              type="button"
                              onClick={() => void handleDeleteApp(app)}
                              className="px-2.5 py-1 text-xs font-medium text-white bg-red-600 hover:bg-red-700 rounded-md"
                            >
                              Bəli
                            </button>
                            <button
                              type="button"
                              onClick={() => setConfirmDeleteAppId(null)}
                              className="px-2.5 py-1 text-xs font-medium text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-md"
                            >
                              Xeyr
                            </button>
                          </div>
                        ) : (
                          <div className="inline-flex items-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => onOpenApp(app.id)}
                              className="p-2 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
                              title="Səhifəyə bax"
                            >
                              <ExternalLink className="w-4 h-4" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleOpenEdit(app)}
                              className="p-2 text-slate-500 hover:text-blue-700 hover:bg-blue-50 rounded-lg transition-colors"
                              title="Yenilə"
                            >
                              <Edit3 className="w-4 h-4" />
                            </button>
                            <button
                              type="button"
                              onClick={() => setConfirmDeleteAppId(app.id)}
                              className="p-2 text-slate-500 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                              title="Sil"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      ) : (
        /* Tab 2: Reports & Review Moderation */
        <div className="space-y-8">
          <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-200 bg-slate-50">
              <h2 className="font-display text-lg font-semibold text-slate-900">
                İstifadəçi şikayətləri ({reports.length})
              </h2>
            </div>

            {reports.length === 0 ? (
              <div className="p-10 text-center text-sm text-slate-500">
                Hazırda yoxlanılacaq şikayət yoxdur.
              </div>
            ) : (
              <div className="divide-y divide-slate-100">
                {reports.map((rep) => {
                  const statusLabel =
                    rep.status === 'pending'
                      ? 'Gözləyir'
                      : rep.status === 'resolved_deleted'
                        ? 'Rəy silindi'
                        : 'Rədd edildi';
                  const statusClass =
                    rep.status === 'pending'
                      ? 'text-amber-700'
                      : rep.status === 'resolved_deleted'
                        ? 'text-red-700'
                        : 'text-slate-500';

                  return (
                    <div key={rep.id} className="p-6 space-y-4">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <div className="flex flex-wrap items-center gap-2 text-sm">
                          <span className="font-semibold text-slate-900">{rep.appName}</span>
                          <span aria-hidden="true" className="text-slate-300">
                            ·
                          </span>
                          <span className="text-amber-700 font-medium">{rep.reason}</span>
                          <span aria-hidden="true" className="text-slate-300">
                            ·
                          </span>
                          <span className={`text-xs font-semibold ${statusClass}`}>
                            {statusLabel}
                          </span>
                        </div>
                        <span className="text-xs text-slate-400 tabular-nums">
                          Şikayətçi: {rep.reporterName}
                        </span>
                      </div>

                      <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
                        <p className="text-xs font-medium text-slate-500">
                          Şikayət edilən rəy ({rep.reviewUserName}):
                        </p>
                        <p className="text-sm text-slate-800">{rep.reviewComment}</p>
                        {rep.details ? (
                          <p className="text-xs text-slate-500 pt-2 border-t border-slate-200 mt-2">
                            Şikayət qeydi: {rep.details}
                          </p>
                        ) : null}
                      </div>

                      {rep.status === 'pending' ? (
                        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                          <input
                            type="text"
                            placeholder="Moderator qeydi (ixtiyari)..."
                            value={adminNoteByReport[rep.id] || ''}
                            onChange={(e) =>
                              setAdminNoteByReport((prev) => ({
                                ...prev,
                                [rep.id]: e.target.value,
                              }))
                            }
                            className="flex-1 px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                          />
                          <div className="flex items-center gap-2 shrink-0">
                            <button
                              type="button"
                              onClick={() => void handleResolveReportDelete(rep)}
                              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-white bg-red-600 hover:bg-red-700 rounded-lg transition-colors whitespace-nowrap"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                              Rəyi Sil və Həll Et
                            </button>
                            <button
                              type="button"
                              onClick={() => void handleDismissReport(rep)}
                              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap"
                            >
                              <Check className="w-3.5 h-3.5" />
                              Rədd et
                            </button>
                          </div>
                        </div>
                      ) : rep.adminNote ? (
                        <p className="text-xs text-slate-500">Qərar qeydi: {rep.adminNote}</p>
                      ) : null}
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* All Active Reviews Audit Table */}
          <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
              <h2 className="font-display text-lg font-semibold text-slate-900">
                Bütün tətbiq rəyləri ({allReviews.length})
              </h2>
              <button
                type="button"
                onClick={() => void loadAllReviews()}
                className="text-xs font-medium text-blue-700 hover:underline"
              >
                Yenilə
              </button>
            </div>
            {loadingReviews ? (
              <div className="p-8 text-center text-sm text-slate-500">Yüklənir...</div>
            ) : allReviews.length === 0 ? (
              <div className="p-8 text-center text-sm text-slate-500">Aktiv rəy yoxdur.</div>
            ) : (
              <div className="divide-y divide-slate-100">
                {allReviews.map((rev) => {
                  const targetApp = appMap.get(rev.appId);
                  return (
                    <div
                      key={`${rev.appId}_${rev.userId}`}
                      className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                    >
                      <div className="space-y-1 min-w-0">
                        <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
                          <span className="font-semibold text-slate-900">
                            {targetApp?.name || rev.appId}
                          </span>
                          <span aria-hidden="true">·</span>
                          <span>{rev.userName}</span>
                          <span aria-hidden="true">·</span>
                          <StarRatingDisplay rating={rev.rating} showNumeric={false} />
                        </div>
                        <p className="text-sm text-slate-700">{rev.comment}</p>
                      </div>
                      <button
                        type="button"
                        onClick={() => void handleDirectAdminDeleteReview(rev)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-red-600 bg-red-50 hover:bg-red-100 rounded-lg shrink-0 self-start sm:self-center"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        Rəyi sil
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Create / Edit APK Modal */}
      {formOpen ? (
        <div className="fixed inset-0 z-50 bg-slate-950/60 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white border border-slate-200 rounded-2xl max-w-3xl w-full max-h-[92vh] overflow-y-auto p-6 sm:p-8 space-y-6 my-auto">
            <div className="flex items-center justify-between border-b border-slate-100 pb-4">
              <h2 className="font-display text-xl font-bold text-slate-900">
                {editingAppId ? 'Tətbiqi yenilə' : 'Yeni Android APK yüklə'}
              </h2>
              <button
                type="button"
                onClick={() => setFormOpen(false)}
                className="p-2 text-slate-400 hover:text-slate-700 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={(e) => void handleSaveApp(e)} className="space-y-6">
              {/* APK File Uploader */}
              <div className="p-5 bg-slate-50 border border-dashed border-slate-300 rounded-xl space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center shrink-0">
                      <FileArchive className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-slate-900">APK Faylı (.apk)</p>
                      <p className="text-xs text-slate-500">
                        {form.apkFileName
                          ? `${form.apkFileName} (${form.fileSizeLabel})`
                          : 'Maksimum 200 MB ölçülü Android APK faylı seçin'}
                      </p>
                    </div>
                  </div>
                  <label className="inline-flex items-center justify-center gap-2 px-4 py-2 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg cursor-pointer whitespace-nowrap shrink-0">
                    <Upload className="w-4 h-4" />
                    {uploadingApk ? 'Yüklənir...' : form.apkFileName ? 'APK dəyişdir' : 'APK seç'}
                    <input
                      type="file"
                      accept=".apk"
                      disabled={uploadingApk}
                      onChange={(e) => void handleApkFileChange(e.target.files?.[0])}
                      className="sr-only"
                    />
                  </label>
                </div>
              </div>

              {/* Core Fields */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1.5">
                    Tətbiqin adı
                  </label>
                  <input
                    type="text"
                    required
                    minLength={BLUEPRINT_LIMITS.appName.min}
                    maxLength={BLUEPRINT_LIMITS.appName.max}
                    value={form.name}
                    onChange={(e) => setForm((p) => ({ ...p, name: e.target.value }))}
                    placeholder="Məs: Atlas Qeydlər"
                    className="w-full px-3.5 py-2.5 text-sm border border-slate-200 rounded-xl focus:outline-none focus:border-blue-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1.5">
                    Paket adı (Package ID)
                  </label>
                  <input
                    type="text"
                    required
                    minLength={BLUEPRINT_LIMITS.packageName.min}
                    maxLength={BLUEPRINT_LIMITS.packageName.max}
                    value={form.packageName}
                    onChange={(e) => setForm((p) => ({ ...p, packageName: e.target.value }))}
                    placeholder="az.qutuapk.atlasnotes"
                    className="w-full px-3.5 py-2.5 text-sm font-mono border border-slate-200 rounded-xl focus:outline-none focus:border-blue-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1.5">
                    Kateqoriya
                  </label>
                  <select
                    value={form.category}
                    onChange={(e) =>
                      setForm((p) => ({ ...p, category: e.target.value as AppCategory }))
                    }
                    className="w-full px-3.5 py-2.5 text-sm border border-slate-200 rounded-xl focus:outline-none focus:border-blue-600"
                  >
                    {APP_CATEGORIES.map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1.5">
                      Versiya
                    </label>
                    <input
                      type="text"
                      required
                      maxLength={BLUEPRINT_LIMITS.version.max}
                      value={form.version}
                      onChange={(e) => setForm((p) => ({ ...p, version: e.target.value }))}
                      placeholder="1.0.0"
                      className="w-full px-3.5 py-2.5 text-sm font-mono border border-slate-200 rounded-xl focus:outline-none focus:border-blue-600"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1.5">
                      Fayl ölçüsü
                    </label>
                    <input
                      type="text"
                      readOnly
                      value={form.fileSizeLabel || 'Avtomatik'}
                      className="w-full px-3.5 py-2.5 text-sm bg-slate-50 text-slate-600 border border-slate-200 rounded-xl tabular-nums"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1.5">
                  Qısa təsvir ({form.shortDescription.length}/{BLUEPRINT_LIMITS.shortDescription.max})
                </label>
                <input
                  type="text"
                  required
                  minLength={BLUEPRINT_LIMITS.shortDescription.min}
                  maxLength={BLUEPRINT_LIMITS.shortDescription.max}
                  value={form.shortDescription}
                  onChange={(e) => setForm((p) => ({ ...p, shortDescription: e.target.value }))}
                  placeholder="Kataloq kartında görünəcək qısa xülasə"
                  className="w-full px-3.5 py-2.5 text-sm border border-slate-200 rounded-xl focus:outline-none focus:border-blue-600"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1.5">
                  Ətraflı təsvir ({form.description.length}/{BLUEPRINT_LIMITS.description.max})
                </label>
                <textarea
                  rows={4}
                  required
                  minLength={BLUEPRINT_LIMITS.description.min}
                  maxLength={BLUEPRINT_LIMITS.description.max}
                  value={form.description}
                  onChange={(e) => setForm((p) => ({ ...p, description: e.target.value }))}
                  placeholder="Tətbiqin imkanları, yeniliklər və Android tələbləri..."
                  className="w-full px-3.5 py-2.5 text-sm border border-slate-200 rounded-xl focus:outline-none focus:border-blue-600"
                />
              </div>

              {/* App Logo Upload & Studio Choices */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-medium text-slate-700">
                    Tətbiqin loqosu (şəkli)
                  </label>
                  <label className="inline-flex items-center gap-1.5 text-xs font-medium text-blue-700 hover:underline cursor-pointer">
                    <ImagePlus className="w-3.5 h-3.5" />
                    {uploadingMedia ? 'Yüklənir...' : 'Öz şəklini yüklə'}
                    <input
                      type="file"
                      accept="image/png,image/jpeg,image/webp"
                      disabled={uploadingMedia}
                      onChange={(e) => void handleIconFileChange(e.target.files?.[0])}
                      className="sr-only"
                    />
                  </label>
                </div>

                <div className="flex flex-wrap items-center gap-3">
                  <div className="w-14 h-14 rounded-2xl overflow-hidden border-2 border-blue-600 bg-slate-100 shrink-0">
                    <SafeImage
                      src={form.iconUrl}
                      alt="Seçilmiş loqo"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    {STUDIO_ASSETS.icons.map((preset) => (
                      <button
                        key={preset.url}
                        type="button"
                        onClick={() => setForm((p) => ({ ...p, iconUrl: preset.url }))}
                        title={preset.label}
                        className={`w-11 h-11 rounded-xl overflow-hidden border transition-all ${
                          form.iconUrl === preset.url
                            ? 'border-blue-600 ring-2 ring-blue-100'
                            : 'border-slate-200 opacity-75 hover:opacity-100'
                        }`}
                      >
                        <SafeImage
                          src={preset.url}
                          alt={preset.label}
                          className="w-full h-full object-cover"
                        />
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Screenshots Uploader */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-medium text-slate-700">
                    Ekran görüntüləri ({form.screenshotUrls.length}/{BLUEPRINT_LIMITS.maxScreenshots})
                  </label>
                  <label className="inline-flex items-center gap-1.5 text-xs font-medium text-blue-700 hover:underline cursor-pointer">
                    <ImagePlus className="w-3.5 h-3.5" />
                    Ekran görüntüsü əlavə et
                    <input
                      type="file"
                      multiple
                      accept="image/png,image/jpeg,image/webp"
                      disabled={uploadingMedia}
                      onChange={(e) => void handleScreenshotsAdd(e.target.files)}
                      className="sr-only"
                    />
                  </label>
                </div>

                {form.screenshotUrls.length > 0 ? (
                  <div className="grid grid-cols-3 sm:grid-cols-4 gap-3">
                    {form.screenshotUrls.map((shot, idx) => (
                      <div
                        key={`${shot}-${idx}`}
                        className="relative aspect-video rounded-lg overflow-hidden border border-slate-200 bg-slate-100 group"
                      >
                        <SafeImage
                          src={shot}
                          alt={`Ekran görüntüsü ${idx + 1}`}
                          className="w-full h-full object-cover"
                        />
                        <button
                          type="button"
                          onClick={() =>
                            setForm((p) => ({
                              ...p,
                              screenshotUrls: p.screenshotUrls.filter((_, i) => i !== idx),
                            }))
                          }
                          aria-label="Şəkli sil"
                          className="absolute top-1 right-1 p-1 bg-slate-900/75 text-white rounded-md opacity-90 hover:bg-red-600"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                ) : null}
              </div>

              {formError ? (
                <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700">
                  {formError}
                </div>
              ) : null}

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setFormOpen(false)}
                  className="px-4 py-2.5 text-sm font-medium text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Ləğv et
                </button>
                <button
                  type="submit"
                  disabled={savingApp || uploadingApk || uploadingMedia}
                  className="px-6 py-2.5 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-xl disabled:opacity-60"
                >
                  {savingApp
                    ? 'Yadda saxlanılır...'
                    : editingAppId
                      ? 'Dəyişiklikləri yadda saxla'
                      : 'Mağazada dərc et'}
                </button>
              </div>
            </form>
          </div>
        </div>
      ) : null}
    </div>
  );
}
