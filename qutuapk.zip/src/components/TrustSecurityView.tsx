import { ArrowLeft, CheckCircle2, Flag, Lock, ShieldCheck, UserCheck } from 'lucide-react';

interface TrustSecurityViewProps {
  onBack: () => void;
}

export function TrustSecurityView({ onBack }: TrustSecurityViewProps) {
  const pillars = [
    {
      icon: ShieldCheck,
      title: 'Yalnız administrator tərəfindən APK yüklənməsi',
      description:
        'Kataloqa yeni Android APK faylları əlavə etmək, versiyanı yeniləmək və ya tətbiqi silmək hüququ yalnız təsdiqlənmiş mağaza administratoruna məxsusdur.',
    },
    {
      icon: Lock,
      title: 'Saxta rəylərə qarşı təsdiqlənmiş yükləmə',
      description:
        'Bir tətbiqə ulduz və şərh yazmaq üçün istifadəçi əvvəlcə həmin tətbiqin APK faylını öz hesabından yükləməlidir. Bu qayda verilənlər bazası səviyyəsində məcburidir.',
    },
    {
      icon: UserCheck,
      title: 'Tətbiq başına bir aktiv rəy limiti',
      description:
        'Hər təsdiqlənmiş istifadəçi bir tətbiq üçün eyni anda yalnız bir aktiv rəy saxlaya bilər. İstifadəçi mövcud rəyini yeniləyə və ya silə bilər, lakin təkrar rəy yaza bilməz.',
    },
    {
      icon: Flag,
      title: 'Şikayətlər və moderator nəzarəti',
      description:
        'Şübhəli, spam və ya təhqiramiz rəylər barədə birbaşa şikayət göndərmək mümkündür. Bütün şikayətlər administrator panelində yoxlanılır və qayda pozan rəylər silinir.',
    },
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 pb-20 space-y-8">
      <button
        type="button"
        onClick={onBack}
        className="inline-flex items-center gap-1.5 text-sm font-medium text-slate-700 hover:text-slate-900"
      >
        <ArrowLeft className="w-4 h-4" />
        Kataloqa qayıt
      </button>

      <div className="space-y-3">
        <h1 className="font-display text-3xl font-bold text-slate-900 text-balance">
          Təhlükəsizlik və Rəy Doğruluğu Qaydaları
        </h1>
        <p className="text-base text-slate-600 leading-relaxed max-w-2xl">
          QutuAPK platforması həm APK fayllarının mənbəyini, həm də istifadəçi reytinqlərinin
          düzgünlüyünü qorumaq üçün avtomatik qayda mexanizmlərindən istifadə edir.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {pillars.map((item) => {
          const Icon = item.icon;
          return (
            <div
              key={item.title}
              className="bg-white border border-slate-200 rounded-2xl p-6 space-y-3"
            >
              <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center">
                <Icon className="w-5 h-5" />
              </div>
              <h2 className="font-display text-lg font-semibold text-slate-900">{item.title}</h2>
              <p className="text-sm text-slate-600 leading-relaxed">{item.description}</p>
            </div>
          );
        })}
      </div>

      <div className="bg-white border border-slate-200 rounded-2xl p-6 flex items-start gap-3">
        <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
        <p className="text-sm text-slate-700">
          Bütün məlumatlar Firebase Authentication və Firestore təhlükəsizlik qaydaları ilə real
          vaxt rejimində qorunur.
        </p>
      </div>
    </div>
  );
}
