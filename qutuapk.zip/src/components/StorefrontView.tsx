import { ArrowUpRight, Download, Search, ShieldCheck, SlidersHorizontal } from 'lucide-react';
import { useMemo, useState, type RefObject } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { recordDownloadAndTrigger } from '../services/storeService';
import {
  APP_CATEGORIES,
  STUDIO_ASSETS,
  type AppCategory,
  type AppListing,
} from '../types/store';
import { SafeImage } from './SafeImage';
import { StarRatingDisplay } from './StarRating';

interface StorefrontViewProps {
  apps: AppListing[];
  loading: boolean;
  categorySectionRef: RefObject<HTMLElement | null>;
  onOpenApp: (appId: string) => void;
  onOpenAdminUpload: () => void;
}

type SortOption = 'newest' | 'downloads' | 'rating';

export function StorefrontView({
  apps,
  loading,
  categorySectionRef,
  onOpenApp,
  onOpenAdminUpload,
}: StorefrontViewProps) {
  const { user, isAdmin } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<'Hamısı' | AppCategory>('Hamısı');
  const [sortBy, setSortBy] = useState<SortOption>('newest');
  const [downloadingId, setDownloadingId] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<string | null>(null);

  const filteredApps = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    const list = apps.filter((app) => {
      const matchesCat = selectedCategory === 'Hamısı' || app.category === selectedCategory;
      if (!matchesCat) return false;
      if (!q) return true;
      return (
        app.name.toLowerCase().includes(q) ||
        app.packageName.toLowerCase().includes(q) ||
        app.shortDescription.toLowerCase().includes(q) ||
        app.category.toLowerCase().includes(q)
      );
    });

    return [...list].sort((a, b) => {
      if (sortBy === 'downloads') return b.downloadCount - a.downloadCount;
      if (sortBy === 'rating') return b.avgRating - a.avgRating || b.reviewCount - a.reviewCount;
      const aTime = a.updatedAt?.toMillis?.() ?? 0;
      const bTime = b.updatedAt?.toMillis?.() ?? 0;
      return bTime - aTime;
    });
  }, [apps, searchQuery, selectedCategory, sortBy]);

  const totalDownloads = useMemo(
    () => apps.reduce((sum, app) => sum + (app.downloadCount || 0), 0),
    [apps],
  );

  const handleQuickDownload = async (app: AppListing) => {
    setDownloadingId(app.id);
    setFeedback(null);
    try {
      await recordDownloadAndTrigger(app, user);
      setFeedback(`${app.name} (v${app.version}) yüklənməyə başladı.`);
    } catch (err) {
      setFeedback(err instanceof Error ? err.message : 'Yükləmə zamanı xəta baş verdi.');
    } finally {
      setDownloadingId(null);
    }
  };

  return (
    <div className="space-y-12 pb-16">
      {/* Hero Split Showcase */}
      <section className="bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 lg:py-14">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-stretch">
            <div className="lg:col-span-7 flex flex-col justify-center">
              <p className="text-xs font-medium tracking-wide text-blue-700 mb-3">
                Yoxlanılmış Android APK Kataloqu
              </p>
              <h1 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-slate-900 text-balance leading-[1.12] mb-4">
                Etibarlı Android tətbiqlərini birbaşa yükləyin
              </h1>
              <p className="text-base sm:text-lg text-slate-600 max-w-2xl leading-relaxed mb-7">
                Yalnız administrator tərəfindən yoxlanılıb əlavə edilən APK paketləri, real
                istifadəçi qiymətləndirmələri və saxta rəylərə qarşı qorunan təhlükəsiz mağaza.
              </p>

              {/* Search Bar */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 max-w-2xl">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="search"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Tətbiq adı, paket və ya kateqoriya axtar..."
                    className="w-full pl-10 pr-4 py-3 text-sm bg-slate-50 border border-slate-200 rounded-xl text-slate-900 placeholder:text-slate-400 focus:outline-none focus:bg-white focus:border-blue-600 transition-colors"
                  />
                </div>
                {isAdmin ? (
                  <button
                    type="button"
                    onClick={onOpenAdminUpload}
                    className="inline-flex items-center justify-center gap-2 px-5 py-3 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-xl transition-colors whitespace-nowrap shrink-0"
                  >
                    <ShieldCheck className="w-4 h-4" />
                    Yeni APK Yüklə
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() =>
                      categorySectionRef.current?.scrollIntoView({ behavior: 'smooth' })
                    }
                    className="inline-flex items-center justify-center gap-2 px-5 py-3 text-sm font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-xl transition-colors whitespace-nowrap shrink-0"
                  >
                    Kataloqa Bax
                    <ArrowUpRight className="w-4 h-4" />
                  </button>
                )}
              </div>

              {/* Clean unboxed summary metrics */}
              <div className="mt-8 pt-6 border-t border-slate-100 grid grid-cols-3 gap-6 max-w-lg">
                <div>
                  <p className="text-2xl font-semibold text-slate-900 tabular-nums">{apps.length}</p>
                  <p className="text-xs text-slate-500 mt-0.5">Aktiv APK</p>
                </div>
                <div>
                  <p className="text-2xl font-semibold text-slate-900 tabular-nums">
                    {totalDownloads.toLocaleString('az-AZ')}
                  </p>
                  <p className="text-xs text-slate-500 mt-0.5">Ümumi yükləmə</p>
                </div>
                <div>
                  <p className="text-2xl font-semibold text-slate-900 tabular-nums">100%</p>
                  <p className="text-xs text-slate-500 mt-0.5">Admin yoxlaması</p>
                </div>
              </div>
            </div>

            <div className="lg:col-span-5">
              <div className="h-64 sm:h-80 lg:h-full min-h-[280px] rounded-2xl overflow-hidden border border-slate-200 bg-slate-100">
                <SafeImage
                  src={STUDIO_ASSETS.heroBanner}
                  alt="Android APK mağazası cihaz görünüşü"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Catalog & Categories Section */}
      <section ref={categorySectionRef} className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 pb-6 border-b border-slate-200">
          {/* Interactive Category Filter Buttons */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 lg:pb-0">
            <button
              type="button"
              onClick={() => setSelectedCategory('Hamısı')}
              className={`px-3.5 py-2 text-xs font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                selectedCategory === 'Hamısı'
                  ? 'bg-slate-900 text-white'
                  : 'bg-white border border-slate-200 text-slate-600 hover:text-slate-900 hover:border-slate-300'
              }`}
            >
              Hamısı
            </button>
            {APP_CATEGORIES.map((category) => (
              <button
                key={category}
                type="button"
                onClick={() => setSelectedCategory(category)}
                className={`px-3.5 py-2 text-xs font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                  selectedCategory === category
                    ? 'bg-slate-900 text-white'
                    : 'bg-white border border-slate-200 text-slate-600 hover:text-slate-900 hover:border-slate-300'
                }`}
              >
                {category}
              </button>
            ))}
          </div>

          {/* Sort Dropdown */}
          <div className="flex items-center gap-2 shrink-0">
            <SlidersHorizontal className="w-4 h-4 text-slate-400" />
            <label htmlFor="store-sort" className="text-xs font-medium text-slate-500">
              Sırala:
            </label>
            <select
              id="store-sort"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as SortOption)}
              className="px-3 py-2 text-xs font-medium bg-white border border-slate-200 rounded-lg text-slate-800 focus:outline-none focus:border-blue-600"
            >
              <option value="newest">Ən yenilər</option>
              <option value="downloads">Ən çox yüklənənlər</option>
              <option value="rating">Ən yüksək reytinq</option>
            </select>
          </div>
        </div>

        {feedback ? (
          <div className="mt-6 px-4 py-3 bg-emerald-50 border border-emerald-200 rounded-xl text-sm text-emerald-800 flex items-center justify-between gap-4">
            <span>{feedback}</span>
            <button
              type="button"
              onClick={() => setFeedback(null)}
              className="text-xs font-medium text-emerald-700 hover:underline whitespace-nowrap"
            >
              Bağla
            </button>
          </div>
        ) : null}

        {/* Populated / Loading / Empty Grid */}
        {loading ? (
          <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map((item) => (
              <div
                key={item}
                className="bg-white border border-slate-200 rounded-2xl p-6 animate-pulse space-y-4"
              >
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-2xl bg-slate-200" />
                  <div className="flex-1 space-y-2">
                    <div className="h-4 bg-slate-200 rounded w-2/3" />
                    <div className="h-3 bg-slate-100 rounded w-1/2" />
                  </div>
                </div>
                <div className="h-10 bg-slate-100 rounded" />
                <div className="h-9 bg-slate-200 rounded-lg" />
              </div>
            ))}
          </div>
        ) : filteredApps.length === 0 ? (
          <div className="mt-10 bg-white border border-slate-200 rounded-2xl p-12 text-center max-w-xl mx-auto">
            <h2 className="font-display text-xl font-semibold text-slate-900 mb-2">
              {apps.length === 0
                ? 'Mağazada hələ tətbiq yoxdur'
                : 'Axtarışa uyğun tətbiq tapılmadı'}
            </h2>
            <p className="text-sm text-slate-600 mb-6">
              {apps.length === 0
                ? 'Administrator ilk APK paketini əlavə etdikdən sonra bütün istifadəçilər tətbiqi yükləyə və qiymətləndirə biləcək.'
                : 'Axtarış sözünü dəyişin və ya bütün kateqoriyaları seçin.'}
            </p>
            {apps.length === 0 && isAdmin ? (
              <button
                type="button"
                onClick={onOpenAdminUpload}
                className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors"
              >
                İlk APK Tətbiqini Yüklə
              </button>
            ) : apps.length > 0 ? (
              <button
                type="button"
                onClick={() => {
                  setSearchQuery('');
                  setSelectedCategory('Hamısı');
                }}
                className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
              >
                Filtrləri sıfırla
              </button>
            ) : null}
          </div>
        ) : (
          <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredApps.map((app) => (
              <article
                key={app.id}
                className="group bg-white border border-slate-200 hover:border-slate-300 rounded-2xl p-6 flex flex-col justify-between transition-all hover:-translate-y-0.5 hover:shadow-sm"
              >
                <div>
                  <div className="flex items-start gap-4">
                    <button
                      type="button"
                      onClick={() => onOpenApp(app.id)}
                      className="w-16 h-16 rounded-2xl overflow-hidden border border-slate-200 bg-slate-100 shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600"
                    >
                      <SafeImage
                        src={app.iconUrl}
                        alt={`${app.name} loqosu`}
                        fallbackLabel={app.name}
                        className="w-full h-full object-cover"
                      />
                    </button>

                    <div className="min-w-0 flex-1">
                      <button
                        type="button"
                        onClick={() => onOpenApp(app.id)}
                        className="text-left font-display text-lg font-semibold text-slate-900 group-hover:text-blue-700 transition-colors truncate block w-full"
                      >
                        {app.name}
                      </button>

                      {/* Zero-Pill Metadata */}
                      <div className="mt-1 flex flex-wrap items-center gap-1.5 text-xs text-slate-500 tabular-nums">
                        <span>{app.category}</span>
                        <span aria-hidden="true">·</span>
                        <span className="font-mono">v{app.version}</span>
                        <span aria-hidden="true">·</span>
                        <span>{app.fileSizeLabel}</span>
                      </div>

                      <div className="mt-2 flex items-center gap-3">
                        <StarRatingDisplay
                          rating={app.avgRating}
                          reviewCount={app.reviewCount}
                        />
                      </div>
                    </div>
                  </div>

                  <p className="mt-4 text-sm text-slate-600 line-clamp-2 leading-relaxed">
                    {app.shortDescription}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between gap-3">
                  <span className="text-xs text-slate-500 tabular-nums inline-flex items-center gap-1.5">
                    <Download className="w-3.5 h-3.5 text-slate-400" />
                    {app.downloadCount.toLocaleString('az-AZ')} yükləmə
                  </span>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => onOpenApp(app.id)}
                      className="px-3 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap"
                    >
                      Ətraflı
                    </button>
                    <button
                      type="button"
                      disabled={downloadingId === app.id}
                      onClick={() => void handleQuickDownload(app)}
                      className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors whitespace-nowrap disabled:opacity-60"
                    >
                      <Download className="w-3.5 h-3.5" />
                      {downloadingId === app.id ? 'Hazırlanır' : 'Yüklə'}
                    </button>
                  </div>
                </div>
              </article>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
