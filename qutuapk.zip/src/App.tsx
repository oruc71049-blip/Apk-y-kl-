/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useRef, useState } from 'react';
import { AdminPanelView } from './components/AdminPanelView';
import { AppDetailView } from './components/AppDetailView';
import { ErrorBoundary } from './components/ErrorBoundary';
import { Header, type ActiveRoute } from './components/Header';
import { StorefrontView } from './components/StorefrontView';
import { TrustSecurityView } from './components/TrustSecurityView';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { subscribeApps, subscribeReports } from './services/storeService';
import type { AppListing, ReviewReport } from './types/store';

function StoreWorkspace() {
  const { user, isAdmin, authReady, authError } = useAuth();
  const [route, setRoute] = useState<ActiveRoute>('store');
  const [selectedAppId, setSelectedAppId] = useState<string | null>(null);
  const [openAdminCreate, setOpenAdminCreate] = useState(false);

  const [apps, setApps] = useState<AppListing[]>([]);
  const [loadingApps, setLoadingApps] = useState(true);
  const [reports, setReports] = useState<ReviewReport[]>([]);
  const categorySectionRef = useRef<HTMLElement | null>(null);

  useEffect(() => {
    const syncFromHash = () => {
      const hash = window.location.hash.replace(/^#/, '');
      if (hash.startsWith('app=')) {
        const id = decodeURIComponent(hash.slice(4));
        if (id) {
          setSelectedAppId(id);
          setRoute('app');
          return;
        }
      }
      if (hash === 'admin') {
        setRoute('admin');
        setSelectedAppId(null);
        return;
      }
      if (hash === 'trust') {
        setRoute('trust');
        setSelectedAppId(null);
        return;
      }
      setRoute('store');
      setSelectedAppId(null);
    };

    syncFromHash();
    window.addEventListener('hashchange', syncFromHash);
    return () => window.removeEventListener('hashchange', syncFromHash);
  }, []);

  useEffect(() => {
    setLoadingApps(true);
    const unsub = subscribeApps((nextApps) => {
      setApps(nextApps);
      setLoadingApps(false);
    });
    return () => unsub();
  }, []);

  useEffect(() => {
    if (!authReady) return;
    const unsub = subscribeReports(isAdmin, user?.uid, setReports);
    return () => unsub();
  }, [authReady, isAdmin, user?.uid]);

  const navigate = (nextRoute: ActiveRoute, appId?: string) => {
    setRoute(nextRoute);
    if (nextRoute === 'app' && appId) {
      setSelectedAppId(appId);
      window.location.hash = `app=${encodeURIComponent(appId)}`;
    } else if (nextRoute === 'admin') {
      setSelectedAppId(null);
      window.location.hash = 'admin';
    } else if (nextRoute === 'trust') {
      setSelectedAppId(null);
      window.location.hash = 'trust';
    } else {
      setSelectedAppId(null);
      window.location.hash = '';
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      <Header
        activeRoute={route}
        onNavigate={navigate}
        onSelectCategorySection={() => {
          setTimeout(() => {
            categorySectionRef.current?.scrollIntoView({ behavior: 'smooth' });
          }, 50);
        }}
      />

      {authError ? (
        <div className="max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 pt-4">
          <div className="px-4 py-3 bg-red-50 border border-red-200 rounded-xl text-sm text-red-700">
            {authError}
          </div>
        </div>
      ) : null}

      <main className="flex-1">
        {route === 'app' && selectedAppId ? (
          <AppDetailView appId={selectedAppId} onBack={() => navigate('store')} />
        ) : route === 'admin' ? (
          <AdminPanelView
            apps={apps}
            reports={reports}
            initialOpenCreate={openAdminCreate}
            onConsumeInitialCreate={() => setOpenAdminCreate(false)}
            onOpenApp={(id) => navigate('app', id)}
            onBackToStore={() => navigate('store')}
          />
        ) : route === 'trust' ? (
          <TrustSecurityView onBack={() => navigate('store')} />
        ) : (
          <StorefrontView
            apps={apps}
            loading={loadingApps}
            categorySectionRef={categorySectionRef}
            onOpenApp={(id) => navigate('app', id)}
            onOpenAdminUpload={() => {
              setOpenAdminCreate(true);
              navigate('admin');
            }}
          />
        )}
      </main>

      <footer className="bg-white border-t border-slate-200 py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <p>© {new Date().getFullYear()} QutuAPK — Təsdiqlənmiş Android APK Mağazası</p>
          <div className="flex items-center gap-6">
            <button
              type="button"
              onClick={() => navigate('store')}
              className="hover:text-slate-900 transition-colors"
            >
              Kataloq
            </button>
            <button
              type="button"
              onClick={() => navigate('trust')}
              className="hover:text-slate-900 transition-colors"
            >
              Təhlükəsizlik qaydaları
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <AuthProvider>
        <StoreWorkspace />
      </AuthProvider>
    </ErrorBoundary>
  );
}
