import express, { type NextFunction, type Request, type Response } from 'express';
import { getApp, getApps, initializeApp } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import fs from 'node:fs';
import path from 'node:path';
import multer from 'multer';

const PORT = Number(process.env.PORT || 3000);
const ADMIN_EMAIL = 'oruc71049@gmail.com';

const ROOT_DIR = process.cwd();
const CONFIG_PATH = path.resolve(ROOT_DIR, 'firebase-applet-config.json');
const UPLOAD_APK_DIR = path.resolve(ROOT_DIR, 'uploads', 'apks');
const UPLOAD_MEDIA_DIR = path.resolve(ROOT_DIR, 'uploads', 'media');

fs.mkdirSync(UPLOAD_APK_DIR, { recursive: true });
fs.mkdirSync(UPLOAD_MEDIA_DIR, { recursive: true });

interface FirebaseAppletConfig {
  projectId: string;
}

function loadFirebaseProjectId(): string {
  const raw = fs.readFileSync(CONFIG_PATH, 'utf-8');
  const parsed = JSON.parse(raw) as FirebaseAppletConfig;
  if (!parsed.projectId) {
    throw new Error('Missing projectId in firebase-applet-config.json');
  }
  return parsed.projectId;
}

const projectId = loadFirebaseProjectId();
const adminApp = getApps().length ? getApp() : initializeApp({ projectId });
const adminAuth = getAuth(adminApp);

interface AuthenticatedRequest extends Request {
  adminUid?: string;
  adminEmail?: string;
}

async function requireAdmin(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction,
): Promise<void> {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      res.status(401).json({ error: 'Authentication token required.' });
      return;
    }
    const token = authHeader.slice('Bearer '.length).trim();
    if (!token) {
      res.status(401).json({ error: 'Empty authentication token.' });
      return;
    }
    const decoded = await adminAuth.verifyIdToken(token);
    if (decoded.email_verified !== true || decoded.email !== ADMIN_EMAIL) {
      res.status(403).json({ error: 'Yalnız administrator bu əməliyyatı icra edə bilər.' });
      return;
    }
    req.adminUid = decoded.uid;
    req.adminEmail = decoded.email;
    next();
  } catch (err) {
    console.error('Admin verification failed:', err);
    res.status(401).json({ error: 'Token doğrulanmadı.' });
  }
}

function sanitizeBaseName(originalName: string): string {
  const base = path.basename(originalName, path.extname(originalName));
  const cleaned = base.replace(/[^a-zA-Z0-9_-]/g, '_').replace(/_+/g, '_').slice(0, 60);
  return cleaned || 'package';
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
}

const apkUpload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, UPLOAD_APK_DIR),
    filename: (_req, file, cb) => {
      const safeBase = sanitizeBaseName(file.originalname);
      const unique = `${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
      cb(null, `${unique}_${safeBase}.apk`);
    },
  }),
  limits: { fileSize: 200 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    if (ext !== '.apk') {
      cb(new Error('Yalnız .apk formatında fayllar yüklənə bilər.'));
      return;
    }
    cb(null, true);
  },
});

const mediaUpload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, UPLOAD_MEDIA_DIR),
    filename: (_req, file, cb) => {
      const ext = path.extname(file.originalname).toLowerCase();
      const safeBase = sanitizeBaseName(file.originalname);
      const unique = `${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
      cb(null, `${unique}_${safeBase}${ext}`);
    },
  }),
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    if (!['.png', '.jpg', '.jpeg', '.webp'].includes(ext)) {
      cb(new Error('Yalnız PNG, JPG və ya WEBP şəkillər qəbul olunur.'));
      return;
    }
    cb(null, true);
  },
});

const SAFE_APK_FILENAME_RE = /^[a-zA-Z0-9._-]+\.apk$/;
const SAFE_MEDIA_FILENAME_RE = /^[a-zA-Z0-9._-]+\.(png|jpg|jpeg|webp)$/;

async function startServer(): Promise<void> {
  const app = express();
  app.use(express.json({ limit: '1mb' }));

  // Upload APK (Admin only)
  app.post('/api/upload/apk', requireAdmin, (req: Request, res: Response) => {
    apkUpload.single('apk')(req, res, (err: unknown) => {
      if (err) {
        const message = err instanceof Error ? err.message : 'APK yükləmə xətası.';
        res.status(400).json({ error: message });
        return;
      }
      if (!req.file) {
        res.status(400).json({ error: 'APK faylı seçilməyib.' });
        return;
      }
      const fileName = req.file.filename;
      res.json({
        apkFileName: fileName,
        apkDownloadUrl: `/api/apks/download/${encodeURIComponent(fileName)}`,
        fileSizeBytes: req.file.size,
        fileSizeLabel: formatBytes(req.file.size),
      });
    });
  });

  // Upload Icon or Screenshot Image (Admin only)
  app.post('/api/upload/media', requireAdmin, (req: Request, res: Response) => {
    mediaUpload.single('image')(req, res, (err: unknown) => {
      if (err) {
        const message = err instanceof Error ? err.message : 'Şəkil yükləmə xətası.';
        res.status(400).json({ error: message });
        return;
      }
      if (!req.file) {
        res.status(400).json({ error: 'Şəkil faylı seçilməyib.' });
        return;
      }
      res.json({
        fileName: req.file.filename,
        url: `/api/media/${encodeURIComponent(req.file.filename)}`,
      });
    });
  });

  // Download APK (Public store download)
  app.get('/api/apks/download/:filename', (req: Request, res: Response) => {
    const filename = String(req.params.filename || '');
    if (!SAFE_APK_FILENAME_RE.test(filename)) {
      res.status(400).json({ error: 'Yanlış fayl adı.' });
      return;
    }
    const resolved = path.resolve(UPLOAD_APK_DIR, filename);
    if (!resolved.startsWith(UPLOAD_APK_DIR + path.sep)) {
      res.status(400).json({ error: 'İcazəsiz yol.' });
      return;
    }
    if (!fs.existsSync(resolved)) {
      res.status(404).json({ error: 'APK faylı serverdə tapılmadı.' });
      return;
    }

    const requestedName = typeof req.query.name === 'string' ? req.query.name : filename;
    const cleanDownloadName = requestedName.replace(/[^a-zA-Z0-9._-]/g, '_');
    const finalName = cleanDownloadName.endsWith('.apk') ? cleanDownloadName : `${cleanDownloadName}.apk`;

    res.setHeader('Content-Type', 'application/vnd.android.package-archive');
    res.download(resolved, finalName);
  });

  // Delete APK file from server (Admin only)
  app.delete('/api/apks/:filename', requireAdmin, (req: Request, res: Response) => {
    const filename = String(req.params.filename || '');
    if (!SAFE_APK_FILENAME_RE.test(filename)) {
      res.status(400).json({ error: 'Yanlış fayl adı.' });
      return;
    }
    const resolved = path.resolve(UPLOAD_APK_DIR, filename);
    if (!resolved.startsWith(UPLOAD_APK_DIR + path.sep)) {
      res.status(400).json({ error: 'İcazəsiz yol.' });
      return;
    }
    if (fs.existsSync(resolved)) {
      fs.unlinkSync(resolved);
    }
    res.json({ deleted: true });
  });

  // Serve uploaded media images
  app.get('/api/media/:filename', (req: Request, res: Response) => {
    const filename = String(req.params.filename || '');
    if (!SAFE_MEDIA_FILENAME_RE.test(filename)) {
      res.status(400).json({ error: 'Yanlış şəkil adı.' });
      return;
    }
    const resolved = path.resolve(UPLOAD_MEDIA_DIR, filename);
    if (!resolved.startsWith(UPLOAD_MEDIA_DIR + path.sep)) {
      res.status(400).json({ error: 'İcazəsiz yol.' });
      return;
    }
    if (!fs.existsSync(resolved)) {
      res.status(404).json({ error: 'Şəkil tapılmadı.' });
      return;
    }
    res.sendFile(resolved);
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(ROOT_DIR, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`QutuAPK server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
