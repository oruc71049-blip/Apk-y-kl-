/**
 * Phase 0: Dirty Dozen Adversarial Security Test Suite for QutuAPK Firestore Rules
 * Verifies identity, integrity, anti-fake-review, PII isolation, and atomic counter invariants.
 */

export interface SecurityTestCase {
  id: number;
  name: string;
  collection: string;
  operation: 'create' | 'update' | 'delete' | 'get' | 'list';
  expected: 'PERMISSION_DENIED';
  payload: Record<string, unknown>;
  invariantChecked: string;
}

export const dirtyDozenTests: SecurityTestCase[] = [
  {
    id: 1,
    name: 'Non-admin APK creation blocked',
    collection: '/apps/evil_app',
    operation: 'create',
    expected: 'PERMISSION_DENIED',
    payload: { id: 'evil_app', name: 'Evil', createdBy: 'regular_user_uid' },
    invariantChecked: 'isAdmin() required on /apps create',
  },
  {
    id: 2,
    name: 'Shadow field injection on App update blocked',
    collection: '/apps/app_1',
    operation: 'update',
    expected: 'PERMISSION_DENIED',
    payload: { downloadCount: 1, isFeatured: true },
    invariantChecked: 'isValidAppListing() keys().hasOnly() + affectedKeys().hasOnly()',
  },
  {
    id: 3,
    name: 'Download counter arbitrary inflation blocked',
    collection: '/apps/app_1',
    operation: 'update',
    expected: 'PERMISSION_DENIED',
    payload: { downloadCount: 999999 },
    invariantChecked: 'downloadCount == existing().downloadCount + 1 && existsAfter(downloads/uid)',
  },
  {
    id: 4,
    name: 'Fake review without prior APK download blocked',
    collection: '/apps/app_1/reviews/user_a',
    operation: 'create',
    expected: 'PERMISSION_DENIED',
    payload: { appId: 'app_1', userId: 'user_a', rating: 5, comment: 'Great app!', verifiedDownload: true },
    invariantChecked: 'exists(/apps/app_1/downloads/user_a) mandatory on review create',
  },
  {
    id: 5,
    name: 'Second active review under arbitrary doc ID blocked',
    collection: '/apps/app_1/reviews/random_doc_id',
    operation: 'create',
    expected: 'PERMISSION_DENIED',
    payload: { appId: 'app_1', userId: 'user_a', rating: 5, comment: 'Second review!' },
    invariantChecked: 'isOwner(userId) forces review doc ID === request.auth.uid',
  },
  {
    id: 6,
    name: 'Identity spoofing on review create blocked',
    collection: '/apps/app_1/reviews/user_b',
    operation: 'create',
    expected: 'PERMISSION_DENIED',
    payload: { appId: 'app_1', userId: 'user_b', rating: 1, comment: 'Fake negative review' },
    invariantChecked: 'isOwner(userId) && data.userId == request.auth.uid',
  },
  {
    id: 7,
    name: 'Out-of-bounds star rating blocked',
    collection: '/apps/app_1/reviews/user_a',
    operation: 'create',
    expected: 'PERMISSION_DENIED',
    payload: { appId: 'app_1', userId: 'user_a', rating: 10, comment: 'Invalid stars' },
    invariantChecked: 'data.rating is int && data.rating >= 1 && data.rating <= 5',
  },
  {
    id: 8,
    name: 'Unverified email spoofing admin blocked',
    collection: '/apps/app_1',
    operation: 'create',
    expected: 'PERMISSION_DENIED',
    payload: { auth: { email: 'oruc71049@gmail.com', email_verified: false } },
    invariantChecked: 'isVerifiedUser() requires request.auth.token.email_verified == true',
  },
  {
    id: 9,
    name: 'Cross-user PII profile read blocked',
    collection: '/users/user_b',
    operation: 'get',
    expected: 'PERMISSION_DENIED',
    payload: { requesterUid: 'user_a' },
    invariantChecked: 'isOwner(userId) || isAdmin() enforced on /users/{userId}',
  },
  {
    id: 10,
    name: 'Self-promotion to Admin blocked',
    collection: '/admins/user_a',
    operation: 'create',
    expected: 'PERMISSION_DENIED',
    payload: { uid: 'user_a', email: 'attacker@example.com' },
    invariantChecked: 'isBootstrappedAdmin() required on /admins create',
  },
  {
    id: 11,
    name: 'Report status shortcutting by non-admin blocked',
    collection: '/reports/app_1__user_b__user_a',
    operation: 'create',
    expected: 'PERMISSION_DENIED',
    payload: { status: 'resolved_deleted', reason: 'Saxta rəy' },
    invariantChecked: "incoming().status == 'pending' on create; only isAdmin() may update status",
  },
  {
    id: 12,
    name: 'Oversized document ID and string exhaustion blocked',
    collection: '/apps/app_1/reviews/' + 'a'.repeat(300),
    operation: 'create',
    expected: 'PERMISSION_DENIED',
    payload: { comment: 'x'.repeat(5000) },
    invariantChecked: 'isValidId() <= 128 chars && comment.size() <= 1000',
  },
];
